@extends('templates/wrapper', [
    'css' => ['body' => 'bg-theme-main'],
])

@section('container')
    <div id="modal-portal"></div>
    <div id="app"></div>
@endsection
